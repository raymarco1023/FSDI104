//OOP
//Object literal
//object constructor

let student1={
    name: "Miles",
    age: 30,
    grade: "A",
    music:["Dre", "Eminem", "Tupac"],
    address:{
        street:"Av. Palm",
        number:"1234",
        zip:"89141",
        city:"San Diego",
        state:"California"
    }



}
console.log(student1);
let student2={
    name: "Jasmine",
    age: 30,
    grade: "A"
}
console.log(student2);


let starbucks=[
    {
        name:"John",
        tier:"Gold",
        stars:"100",
        rewards:["Free Coffee"]
    },
    {
        name:"Joe",
        tier:"Gold",
        stars:"30",
        rewards:"Free Sandwich"
    },
    {
        name:"Chris",
        tier:"Gold",
        stars:"50",
        rewards:"Free Drink"
    }

];
//mortal solution
function displayClients(){
    console.log(starbucks[0].name);
    console.log(starbucks[1].name);
    console.log(starbucks[2].name);
    //inmortal solution
    for(let i=0;i<starbucks.length;i++){
        console.log(starbucks[i].name);
    }
}
displayClients();